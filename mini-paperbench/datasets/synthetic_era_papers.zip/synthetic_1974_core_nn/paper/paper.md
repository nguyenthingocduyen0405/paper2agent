# A CORE-ECONOMICAL NEAREST-NEIGHBOUR RECOGNIZER FOR HAND-PRINTED NUMERALS ON A MINICOMPUTER WITH 8K WORDS OF MEMORY

R. J. Punchcard and D. Q. Teletype
Department of Computing Services, Building 7 (Basement, behind the boiler)

*Synthetic paper for judge evaluation, written in the style of the 1970s. The authors, the department and the minicomputer are fictional. The numbers come from the reference implementation.*

**Abstract** — The nearest-neighbour rule is known to perform admirably, provided one can afford to store every training sample. We cannot. Our minicomputer has 8K words of core memory, of which the operating system takes most and the payroll program takes the rest at month end. We describe a recognizer that keeps at most 64 prototypes, reads its training tape exactly once, and decides which prototype to forget by asking which one has been least useful lately. Accuracy is within about seven points of the full nearest-neighbour rule while using about 4% of the storage.

## 1. INTRODUCTION

Since the energy crisis our computing centre has been asked to "do more with less". This paper is our response. The full nearest-neighbour rule stores all training samples; we propose instead to store only the samples that the recognizer gets wrong (in the spirit of condensing), and, when core is full, to *evict* the prototype that has been consulted least often. To prevent the eviction of promising young prototypes before they have had a chance to prove themselves, we grant every new prototype a period of *tenure*.

## 2. DATA

The numerals are taken from the "digits" collection of the scikit-learn library: 1,797 numerals, 8 × 8 picture elements each, ten classes. Each picture element is an integer from 0 to 16 and is used **as is, without scaling** (scaling would require floating point, which our machine performs reluctantly and at great cost).

The **first 1,500** numerals, in their original order, form the training tape. The **last 297** numerals form the test tape.

## 3. THE RECOGNIZER

**3.1 Distance.** The distance between two numerals is the **city-block distance**, the sum over the 64 picture elements of the absolute differences. We avoid the Euclidean distance because our FORTRAN library computes square roots by a method best described as "eventually".

**3.2 Decision rule.** A numeral is given the class of the single nearest stored prototype (**1-NN**). If several prototypes are at the same smallest distance, the one **stored earliest** is used.

**3.3 Reading the training tape.** The tape is read **exactly once, in order** (our tape drive reads forward only). For each training numeral, in order:

(a) If core is empty, the numeral is stored as a prototype.

(b) Otherwise, the nearest prototype is found as in 3.2, and its **consultation count is increased by one**, whether or not its class is correct.

(c) If the nearest prototype's class differs from the numeral's class, the numeral is stored as a new prototype. A numeral that is classified correctly is **not** stored.

(d) A new prototype starts with a consultation count of **zero**.

**3.4 Eviction.** Core holds at most **64 prototypes**. When a new prototype must be stored and core already holds 64, one prototype is first evicted: the one with the **smallest consultation count**. If several are tied, the **oldest** (stored earliest) is evicted.

**3.5 Tenure.** A prototype that was stored fewer than **50** training numerals ago may not be evicted. (Formally, if the current numeral is number i on the tape and a prototype was stored while reading numeral b, it is protected while i − b < 50.) Since at most 49 prototypes can have been stored during the last 49 numerals, an unprotected prototype is always available.

**3.6 Tape rewinds.** Every **500** training numerals (after numerals 500 and 1,000), the operator rewinds the tape to change reels, and the consultation counts of all stored prototypes are **halved, rounding down** (integer division). This prevents a prototype from resting forever on early glories.

## 4. COMPARISON

For comparison, we also report the full 1-NN rule, which stores all 1,500 training numerals and uses the same city-block distance. We were able to run this only by borrowing core from the payroll program between paydays.

## 5. RESULTS

Both recognizers classify the 297 numerals of the test tape. The two accuracies, the number of evictions, and the number of prototypes in core at the end of training are printed on the line printer and saved to a results file.

| Recognizer | Prototypes stored | Test accuracy | Evictions |
| --- | --- | --- | --- |
| Full 1-NN | 1,500 | 93.3 % | — |
| Core-economical (ours) | 64 | 86.2 % | 65 |

Our recognizer achieves 86.2 % using 64 prototypes, a 96 % saving in core, at a cost of 7.1 points of accuracy. We consider this an excellent bargain, and so did the payroll department.

## 6. CONCLUSION

A recognizer need not remember everything; it need only remember what was useful, and forget the rest in good order. The authors note that the same principle has been applied for many years by the authors' own memories, with comparable results.
