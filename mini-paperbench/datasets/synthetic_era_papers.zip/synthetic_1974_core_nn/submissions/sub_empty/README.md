# Core-economical nearest neighbour reproduction

Not implemented yet.
