# Core-economical nearest-neighbour reproduction

- `src/memory.py`: the 64-prototype core memory with eviction
- `src/data.py`: training and test tapes
- `src/train.py`: training, the full 1-NN comparison and evaluation

Run `bash reproduce.sh`. Results are written to `results/results.json`.
