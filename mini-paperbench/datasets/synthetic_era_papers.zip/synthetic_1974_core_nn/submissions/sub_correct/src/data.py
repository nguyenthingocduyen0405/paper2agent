from sklearn.datasets import load_digits


def load_tapes():
    digits = load_digits()
    X = digits.data.astype(int)
    y = digits.target
    return X[:1500], y[:1500], X[1500:], y[1500:]
