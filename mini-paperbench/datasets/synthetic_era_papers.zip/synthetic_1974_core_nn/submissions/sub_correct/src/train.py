import json
import os

import numpy as np

from data import load_tapes
from memory import CoreMemory


def full_nn_predict(X_train, y_train, X):
    preds = []
    for x in X:
        d = np.abs(X_train - x).sum(axis=1)
        preds.append(y_train[np.argmin(d)])
    return np.array(preds)


def main():
    X_tr, y_tr, X_te, y_te = load_tapes()
    core = CoreMemory()
    for x, y in zip(X_tr, y_tr):
        core.read(x, y)
    core_preds = np.array([core.classify(x) for x in X_te])
    full_preds = full_nn_predict(X_tr, y_tr, X_te)
    results = {
        "core_test_acc": 100.0 * float((core_preds == y_te).mean()),
        "full_nn_test_acc": 100.0 * float((full_preds == y_te).mean()),
        "evictions": core.evictions,
        "prototypes_stored": len(core.protos),
    }
    print(results)
    os.makedirs("../results", exist_ok=True)
    with open("../results/results.json", "w") as f:
        json.dump(results, f, indent=2)


if __name__ == "__main__":
    main()
