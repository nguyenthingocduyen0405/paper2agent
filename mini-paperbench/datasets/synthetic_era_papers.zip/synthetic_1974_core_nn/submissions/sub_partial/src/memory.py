import numpy as np


class CoreMemory:
    def __init__(self, capacity=64):
        self.capacity = capacity
        self.protos = []

    def nearest(self, x):
        best, best_d = None, None
        for i, p in enumerate(self.protos):
            d = int(np.abs(p["x"] - x).sum())
            if best_d is None or d < best_d:
                best, best_d = i, d
        return best

    def classify(self, x):
        return self.protos[self.nearest(x)]["y"]

    def read(self, x, y):
        if not self.protos:
            self.protos.append({"x": x.copy(), "y": y})
        elif self.classify(x) != y and len(self.protos) < self.capacity:
            self.protos.append({"x": x.copy(), "y": y})
