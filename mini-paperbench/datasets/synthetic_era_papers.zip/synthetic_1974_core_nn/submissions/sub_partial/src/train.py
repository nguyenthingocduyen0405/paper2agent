import numpy as np

from data import load_tapes
from memory import CoreMemory


def main():
    X_tr, y_tr, X_te, y_te = load_tapes()
    core = CoreMemory()
    for x, y in zip(X_tr, y_tr):
        core.read(x, y)
    preds = np.array([core.classify(x) for x in X_te])
    print(f"Test accuracy: {100.0 * (preds == y_te).mean():.1f}%")


if __name__ == "__main__":
    main()
