import numpy as np


class CoreMemory:
    def __init__(self, capacity=64, rewind_every=500, k=3):
        self.capacity = capacity
        self.rewind_every = rewind_every
        self.k = k
        self.protos = []
        self.seen = 0
        self.evictions = 0

    def nearest_k(self, x, k):
        d = [(int(np.abs(p["x"] - x).sum()), i) for i, p in enumerate(self.protos)]
        return [i for _, i in sorted(d)[:k]]

    def classify(self, x):
        idx = self.nearest_k(x, self.k)
        labels = [self.protos[i]["y"] for i in idx]
        votes = {lab: labels.count(lab) for lab in labels}
        top = max(votes.values())
        return next(lab for lab in labels if votes[lab] == top)

    def read(self, x, y):
        self.seen += 1
        if self.protos:
            self.protos[self.nearest_k(x, 1)[0]]["count"] += 1
        if len(self.protos) >= self.capacity:
            del self.protos[0]
            self.evictions += 1
        self.protos.append({"x": x.copy(), "y": y, "count": 0})
        if self.seen % self.rewind_every == 0:
            for p in self.protos:
                p["count"] //= 2
