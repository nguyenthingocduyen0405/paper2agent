import numpy as np


class CoreMemory:
    def __init__(self, capacity=64, tenure=5, rewind_every=500):
        self.capacity = capacity
        self.tenure = tenure
        self.rewind_every = rewind_every
        self.protos = []  # in order of storage, oldest first
        self.seen = 0
        self.evictions = 0

    def nearest(self, x):
        best, best_d = None, None
        for i, p in enumerate(self.protos):
            d = float(np.sqrt(((p["x"] - x) ** 2).sum()))
            if best_d is None or d <= best_d:
                best, best_d = i, d
        return best

    def classify(self, x):
        return self.protos[self.nearest(x)]["y"]

    def read(self, x, y):
        self.seen += 1
        if not self.protos:
            self._store(x, y)
        else:
            i = self.nearest(x)
            self.protos[i]["count"] += 1
            if self.protos[i]["y"] != y:
                if len(self.protos) > self.capacity:
                    self._evict()
                self._store(x, y)
        if self.seen % self.rewind_every == 0:
            for p in self.protos:
                p["count"] /= 2

    def _store(self, x, y):
        self.protos.append({"x": x.copy(), "y": y, "count": 0, "born": self.seen})

    def _evict(self):
        eligible = [i for i, p in enumerate(self.protos) if self.seen - p["born"] >= self.tenure]
        victim = min(eligible, key=lambda i: (self.protos[i]["count"], -i))
        del self.protos[victim]
        self.evictions += 1
