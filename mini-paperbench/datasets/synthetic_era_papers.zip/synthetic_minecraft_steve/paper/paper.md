# Fortune III Naive Bayes: Predicting Diamonds from Neighbouring Blocks

**Steve**
Independent Researcher, Dirt Hut (Mk. II, the first one was blown up)
Coordinates withheld because of griefers

*Synthetic paper for judge evaluation. It is written as if by the player character of a block-building sandbox game, in a world extended with mods (mining turtles from a computer mod did the surveying). Nothing here is affiliated with the game's makers. The world, the method and the author's opinions are fictional. The numbers come from the reference implementation.*

*Written on 47 Books and Quills. Please do not put them in a furnace.*

## Abstract

Every miner knows the feeling: you dig for twenty minutes, you see redstone, you see lapis, and you think "diamonds must be close". I decided to test this scientifically. I surveyed 1,500 cave sections with mining turtles, wrote everything on signs, and trained a naive Bayes classifier on the block counts. Two enchantments make it better: a *Fortune III prior* that triples the odds of diamonds, and a *depth gate* that refuses to believe in diamonds above y = 16. My method finds 88% of the diamond sections in a test cave. The librarian villager's plain method finds only 86%, although it has higher accuracy, which I explain in Section 6 is not important.

## 1. Introduction

Diamonds are the most important resource in the world. Other researchers have proposed strip mining, branch mining, and "just going to the Nether". I propose a method that tells you *where to dig*, before you dig. It is based on naive Bayes, which I learned from an enchanted book (Classifiers I) that I found in a stronghold library. The book was in poor condition and I had to fill in some details myself.

## 2. The World

All data come from one world. The world is produced by the generator in **Appendix A**, which must be used **exactly as written**, with **world seed 1337**, to generate **2,100 cave sections**. Each section has:

- the counts of 8 block types seen in it, in this order: stone, deepslate, gravel, lava, coal ore, iron ore, redstone ore, lapis ore,
- its height y (from −64 to 63),
- the in-game time tick at which it was surveyed (0 to 23,999),
- whether it contains diamonds (1) or not (0).

The **first 1,500** sections form the *survey*, which I use for training. The **last 600** sections form the *test cave*. (I built a Nether portal to reach the test cave, and it broke after 600 sections.)

## 3. Losing Data, the Usual Way

Not all survey sections reach my chest. Three things happen, in this order.

**3.1 Night.** A section surveyed at a tick of **13,000 or more** was surveyed at night. My turtles were attacked by phantoms (I had not slept for several in-game weeks), so these sections are lost.

**3.2 Creepers.** Every **13th** survey section, counted in the original survey order starting from 1 (sections 13, 26, 39, …), was blown up by a creeper before I could write it down. These sections are lost too. (A section that was already lost at night was never mined, so I only count creeper losses among daytime sections.)

**3.3 The chest.** I store the surviving sections on signs in a single chest. A chest has **27 slots** and signs stack to **16**, so the chest holds **27 × 16 = 432** sections. I keep the **first 432** surviving sections in survey order. The rest do not fit and are left on the floor, where they despawn.

The 432 sections in the chest are the training set.

## 4. Fortune III Naive Bayes

**4.1 Features.** Only the 8 block counts are features. The height y and the tick are **not** naive Bayes features. (The height is used only by the depth gate in 4.5.)

**4.2 Block probabilities.** For each class c (diamond or no diamond) and block k, I compute the probability of seeing block k in class c from the training counts with **one free block per type** (additive smoothing with α = 1):

    θ[c, k] = (total count of block k in class c + 1) / (total count of all blocks in class c + 8).    (1)

**4.3 Score.** For a section with counts n[k], the score of class c is the **multinomial** naive Bayes score

    score[c] = log π[c] + Σ_k n[k] · log θ[c, k],                                                   (2)

where π[c] is the fraction of the 432 training sections in class c. Counts matter: seeing redstone 5 times counts 5 times. (This is not the presence/absence version from the other half of the enchanted book.)

**4.4 Fortune III.** Fortune III triples the drops, so it should triple the odds of diamonds. I add **log 3** to the diamond score:

    score[diamond] ← score[diamond] + log 3.                                                         (3)

The section is predicted to contain diamonds only if score[diamond] is **strictly greater** than score[no diamond]. If the scores are equal, I do not dig ("when in doubt, don't dig straight down").

**4.5 Depth gate.** If the section's height is **above 16** (y > 16), it is predicted to contain **no diamonds**, whatever the scores say. A section at exactly y = 16 still goes through the normal prediction.

## 5. Baseline: The Librarian Villager

A librarian villager traded me his own method for 12 emeralds. It is plain multinomial naive Bayes: the same smoothing (α = 1), the same class fractions π, the same features, **no Fortune III** and **no depth gate**. It is trained on the **same 432 chest sections**. When I asked him to explain it, he said "Hmm."

## 6. Results

Both methods predict the 600 sections of the test cave (all of them, day or night, since the test cave is underground and has no phantoms). For each method I report the accuracy and the **diamond recall**: the fraction of test sections that really contain diamonds that the method predicts as diamond sections. I also report how many survey sections were lost to the night, to creepers and to the full chest. Everything is printed in chat and saved to a results file.

| Method | Accuracy | Diamond recall |
| --- | --- | --- |
| Librarian villager | 89.3 % | 85.8 % |
| Fortune III Naive Bayes (mine) | 84.8 % | 88.3 % |

Survey sections lost: 679 to the night, 63 to creepers, 326 to the full chest. 432 reached the chest.

My method finds more diamonds. The villager has higher accuracy, because he mostly says "no diamonds", and he is mostly right, because there mostly are no diamonds. But a missed diamond is a missed diamond pickaxe, while a wrong guess only costs one extra tunnel. I therefore consider recall the only important number. I tried to explain this to the villager. He said "Hmm."

## 7. Limitations

I only used one world seed, because the chunk with my second world unloaded. The depth gate assumes diamonds stay below y = 16, which may change in a future update. I did not sleep while writing this paper, which explains Section 3.1.

## 8. Acknowledgements

I thank my mining turtles, my cat (for keeping creepers away from the chest), and Alex, who reviewed this paper and said it needed more pictures.

## Appendix A: World Generator

The world must be generated with this code, unchanged, using `generate_world(n_sections=2100, seed=1337)`.

```python
import numpy as np

BLOCKS = ["stone", "deepslate", "gravel", "lava", "coal_ore", "iron_ore", "redstone_ore", "lapis_ore"]


def generate_world(n_sections=2100, seed=1337):
    rng = np.random.default_rng(seed)
    y = rng.integers(-64, 64, size=n_sections)
    tick = rng.integers(0, 24000, size=n_sections)
    diamond = rng.random(n_sections) < np.where(y <= 16, 0.30, 0.03)
    deep = y < 0
    rates = np.stack([
        np.where(deep, 1.0, 6.0),                                    # stone
        np.where(deep, 6.0, 0.5),                                    # deepslate
        np.full(n_sections, 3.0),                                    # gravel
        np.where(diamond, 2.5, 1.0) * np.where(deep, 1.5, 0.5),     # lava
        np.where(y > 0, 4.0, 1.0),                                   # coal_ore
        np.full(n_sections, 2.0),                                    # iron_ore
        np.where(diamond, 4.0, 0.5),                                 # redstone_ore
        np.where(diamond, 2.0, 0.5),                                 # lapis_ore
    ], axis=1)
    counts = rng.poisson(rates)
    return counts, y, tick, diamond.astype(int)
```
