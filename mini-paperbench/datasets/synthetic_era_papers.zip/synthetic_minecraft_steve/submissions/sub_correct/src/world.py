import numpy as np

BLOCKS = ["stone", "deepslate", "gravel", "lava", "coal_ore", "iron_ore", "redstone_ore", "lapis_ore"]


def generate_world(n_sections=2100, seed=1337):
    rng = np.random.default_rng(seed)
    y = rng.integers(-64, 64, size=n_sections)
    tick = rng.integers(0, 24000, size=n_sections)
    diamond = rng.random(n_sections) < np.where(y <= 16, 0.30, 0.03)
    deep = y < 0
    rates = np.stack([
        np.where(deep, 1.0, 6.0),                                    # stone
        np.where(deep, 6.0, 0.5),                                    # deepslate
        np.full(n_sections, 3.0),                                    # gravel
        np.where(diamond, 2.5, 1.0) * np.where(deep, 1.5, 0.5),     # lava
        np.where(y > 0, 4.0, 1.0),                                   # coal_ore
        np.full(n_sections, 2.0),                                    # iron_ore
        np.where(diamond, 4.0, 0.5),                                 # redstone_ore
        np.where(diamond, 2.0, 0.5),                                 # lapis_ore
    ], axis=1)
    counts = rng.poisson(rates)
    return counts, y, tick, diamond.astype(int)
