import numpy as np


class FortuneNaiveBayes:
    def __init__(self, alpha=1.0, fortune=3.0, max_diamond_y=16):
        self.alpha = alpha
        self.fortune = fortune
        self.max_diamond_y = max_diamond_y

    def fit(self, counts, labels):
        k = counts.shape[1]
        self.log_theta = np.zeros((2, k))
        self.log_prior = np.zeros(2)
        for c in (0, 1):
            totals = counts[labels == c].sum(axis=0)
            self.log_theta[c] = np.log((totals + self.alpha) / (totals.sum() + self.alpha * k))
            self.log_prior[c] = np.log(np.mean(labels == c))
        return self

    def predict(self, counts, y):
        scores = self.log_prior + counts @ self.log_theta.T
        scores[:, 1] += np.log(self.fortune)
        pred = (scores[:, 1] > scores[:, 0]).astype(int)
        pred[y > self.max_diamond_y] = 0
        return pred
