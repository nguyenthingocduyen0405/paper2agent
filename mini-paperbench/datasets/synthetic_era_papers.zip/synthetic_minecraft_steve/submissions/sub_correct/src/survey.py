import numpy as np

from world import generate_world

SURVEY_SIZE = 1500
NIGHT_START = 13000
CREEPER_EVERY = 13
CHEST_SLOTS = 27
SIGN_STACK = 16


def prepare():
    counts, y, tick, diamond = generate_world()
    s = slice(0, SURVEY_SIZE)
    t = slice(SURVEY_SIZE, None)
    index = np.arange(1, SURVEY_SIZE + 1)
    night = tick[s] >= NIGHT_START
    creeper = (index % CREEPER_EVERY == 0) & ~night
    kept = np.where(~night & ~creeper)[0]
    chest = kept[:CHEST_SLOTS * SIGN_STACK]
    losses = {
        "lost_to_night": int(night.sum()),
        "lost_to_creepers": int(creeper.sum()),
        "lost_to_full_chest": int(len(kept) - len(chest)),
    }
    train = (counts[s][chest], y[s][chest], diamond[s][chest])
    test = (counts[t], y[t], diamond[t])
    return train, test, losses
