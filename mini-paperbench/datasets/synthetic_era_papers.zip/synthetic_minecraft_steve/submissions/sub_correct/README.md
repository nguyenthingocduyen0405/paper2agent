# Fortune III Naive Bayes reproduction

- `src/world.py`: the world generator from Appendix A
- `src/survey.py`: night, creeper and chest filtering
- `src/nb.py`: Fortune III naive Bayes
- `src/train.py`: training of both models and evaluation

Run `bash reproduce.sh`. Results are written to `results/results.json`.
