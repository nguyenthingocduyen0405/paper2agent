import numpy as np

from world import generate_world


def prepare():
    counts, y, tick, diamond = generate_world()
    s = slice(0, 1500)
    t = slice(1500, None)
    kept = np.where(tick[s] < 13000)[0][:27 * 16]
    train = (counts[s][kept], y[s][kept], diamond[s][kept])
    test = (counts[t], y[t], diamond[t])
    return train, test
