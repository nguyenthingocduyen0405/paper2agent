from nb import FortuneNaiveBayes
from survey import prepare


def main():
    (c_tr, y_tr, d_tr), (c_te, y_te, d_te) = prepare()
    model = FortuneNaiveBayes().fit(c_tr, d_tr)
    acc = 100.0 * (model.predict(c_te, y_te) == d_te).mean()
    print(f"Accuracy in the test cave: {acc:.1f}%")


if __name__ == "__main__":
    main()
