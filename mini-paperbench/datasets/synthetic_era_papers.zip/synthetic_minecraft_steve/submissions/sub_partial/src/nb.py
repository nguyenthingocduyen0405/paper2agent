import numpy as np


class FortuneNaiveBayes:
    def __init__(self, alpha=1.0):
        self.alpha = alpha

    def fit(self, counts, labels):
        k = counts.shape[1]
        self.log_theta = np.zeros((2, k))
        self.log_prior = np.zeros(2)
        for c in (0, 1):
            totals = counts[labels == c].sum(axis=0)
            self.log_theta[c] = np.log((totals + self.alpha) / (totals.sum() + self.alpha * k))
            self.log_prior[c] = np.log(np.mean(labels == c))
        return self

    def predict(self, counts, y):
        scores = self.log_prior + counts @ self.log_theta.T
        return (scores[:, 1] > scores[:, 0]).astype(int)
