import json
import os

import numpy as np

from nb import FortuneNaiveBayes
from survey import prepare


class PlainNaiveBayes:
    """The librarian villager's method: multinomial naive Bayes, nothing else."""

    def fit(self, counts, labels):
        k = counts.shape[1]
        self.log_theta = np.zeros((2, k))
        self.log_prior = np.zeros(2)
        for c in (0, 1):
            totals = counts[labels == c].sum(axis=0)
            self.log_theta[c] = np.log((totals + 1.0) / (totals.sum() + 1.0 * k))
            self.log_prior[c] = np.log(np.mean(labels == c))
        return self

    def predict(self, counts, y):
        scores = self.log_prior + counts @ self.log_theta.T
        return (scores[:, 1] > scores[:, 0]).astype(int)


def scores(pred, truth):
    acc = 100.0 * float((pred == truth).mean())
    recall = 100.0 * float(pred[truth == 1].mean())
    return acc, recall


def main():
    (c_tr, y_tr, d_tr), (c_te, y_te, d_te), losses = prepare()
    steve = FortuneNaiveBayes().fit(c_tr, d_tr, y_tr)
    villager = PlainNaiveBayes().fit(c_tr, d_tr)
    s_acc, s_rec = scores(steve.predict(c_te, y_te), d_te)
    v_acc, v_rec = scores(villager.predict(c_te, y_te), d_te)
    results = {
        "fortune_nb_accuracy": s_acc, "fortune_nb_diamond_recall": s_rec,
        "villager_nb_accuracy": v_acc, "villager_nb_diamond_recall": v_rec,
        "training_sections": int(len(d_tr)), **losses,
    }
    print(results)
    os.makedirs("../results", exist_ok=True)
    with open("../results/results.json", "w") as f:
        json.dump(results, f, indent=2)


if __name__ == "__main__":
    main()
