import numpy as np


class FortuneNaiveBayes:
    def __init__(self, fortune=3.0, max_diamond_y=16):
        self.fortune = fortune
        self.max_diamond_y = max_diamond_y

    @staticmethod
    def _features(counts, y):
        seen = (counts > 0).astype(float)
        deep = (y < 0).astype(float)[:, None]
        return np.hstack([seen, deep])

    def fit(self, counts, labels, y):
        X = self._features(counts, y)
        self.theta = np.zeros((2, X.shape[1]))
        for c in (0, 1):
            Xc = X[labels == c]
            self.theta[c] = (Xc.sum(axis=0) + 1.0) / (len(Xc) + 2.0)
        return self

    def predict(self, counts, y):
        X = self._features(counts, y)
        scores = np.log(0.5) + X @ np.log(self.theta).T + (1 - X) @ np.log(1 - self.theta).T
        scores[:, 1] += np.log(self.fortune)
        pred = (scores[:, 1] > scores[:, 0]).astype(int)
        pred[y > self.max_diamond_y] = 0
        return pred
