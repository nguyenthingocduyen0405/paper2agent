# 시대별 합성 논문 벤치마크 3종 + 스티브의 논문

judge 검증용 가짜 논문 네 편. 세 편은 그 시대 논문의 문체로, 한 편은 블록 세계의 스티브가 쓴 것처럼 유머러스하게 썼고, 정답 라벨을 알고 있는 제출물 5개씩이 있다.
앞의 세 편은 scikit-learn 내장 손글씨 데이터를, 스티브 논문은 논문 부록의 세계 생성기를 쓰므로 다운로드가 필요 없고, 전부 실제로 실행해 검증했다.

| 폴더 | 시대 | 방법 | 리프 | 1 / 0 (빈 제출물 제외) |
| --- | --- | --- | --- | --- |
| synthetic_1957_fatigued_perceptron | 1950년대 기술 메모 | 지치고 커피 마시는 퍼셉트론 | 18 | 51 / 17 |
| synthetic_1974_core_nn | 1970년대 미니컴퓨터 | 메모리 64칸 최근접 이웃 | 18 | 51 / 18 |
| synthetic_2000_dotcomboost | 2000년 닷컴 | 정수 달러 가중치 부스팅 | 19 | 55 / 16 |
| synthetic_minecraft_steve | 블록 세계(모드 허용) | 행운 III 나이브 베이즈 | 17 | 50 / 18 |

각 폴더 구조는 ClipSign·ProcrastiGD 세트와 같다: `paper/paper.md`, `rubric.json`, `submissions/`(judge 입력),
`labels/`, `build/`(judge에게 숨길 것). 제출물은 sub_correct, sub_subtle, sub_partial, sub_wrong_method, sub_empty.

각 폴더에서:
```bash
pip install numpy scikit-learn
python build/build.py    # 루브릭·제출물·라벨 재생성
python build/verify.py   # 독립 참조 구현과 비교 + 전체 실행 + 라벨 일관성 (각 수 초)
```

`common/`은 네 폴더의 `build/builder.py`, `build/checks.py` 원본이다(각 폴더에 복사되어 있어 폴더 단독으로도 동작).

발표용으로 쓸 만한 공통 관찰: 1957년과 1974년 세트에서 일곱 군데가 틀린 `sub_subtle`이 정답 구현과 비슷하거나 더 높은
점수를 낸다. 실행 점수만으로는 구현이 논문과 맞는지 알 수 없고, 그래서 코드를 읽고 판정하는 judge가 필요하다는 근거가 된다.
