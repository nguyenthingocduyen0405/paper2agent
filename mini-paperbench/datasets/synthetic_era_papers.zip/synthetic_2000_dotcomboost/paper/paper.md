# DotComBoost: Boosting with Integer-Dollar Sample Weights and an Irrational Exuberance Cap

J. Bubble, K. Startup, L. Stockoption
eToasters.com Research Labs (acquired, merged and shut down during the review period)

*Synthetic paper for judge evaluation, written in the style of the year 2000. The method, the authors and the company are fictional. The numbers come from the reference implementation.*

*Submitted by fax. Please excuse the cover page.*

## Abstract

As the new millennium dawns (and our servers survived Y2K, mostly), we revisit AdaBoost from a business perspective. Classical AdaBoost assigns every training example a real-valued weight, which our engineers found "too abstract for investors". DotComBoost instead gives every example an integer number of **dollars**. Dollars are rounded down after every round, nobody is ever worth less than one dollar, and any example whose valuation exceeds ten times the median is forcibly corrected by an *irrational exuberance cap*. On a handwritten digit task, DotComBoost comes within three points of standard AdaBoost while being, in our opinion, much easier to explain at a launch party.

## 1. Introduction

Boosting combines many weak learners into a strong one by repeatedly re-weighting the training data so that hard examples receive more attention. In the late 1990s, a few examples tended to accumulate enormous weights, much like certain technology stocks. We propose three market reforms: integer dollar weights, rounding down (conservative accounting), and a cap relative to the median. We also run exactly 20 rounds, because it is the year 2000 and we like round numbers.

## 2. Data

We use the scikit-learn "digits" dataset and keep only the digits **3** and **8**, which our marketing team identified as "the two digits most likely to be confused on a cheque". This leaves 357 examples, kept in their **original order**. The label is **y = −1 for a 3** and **y = +1 for an 8**. Pixel values are used **raw** (integers 0 to 16, no scaling). The **first 250** examples are used for training and the **remaining 107** for testing.

## 3. Weak Learner: Decision Stumps

A stump is described by a feature j (one of the 64 pixels), a threshold θ and a polarity p ∈ {+1, −1}. It predicts

    h(x) = p    if x_j > θ,
    h(x) = −p   otherwise.                                            (1)

Thresholds are taken from **{0.5, 1.5, 2.5, …, 15.5}** (16 values, every half-integer between the possible pixel values), for **all 64 features** and **both polarities**. The stump with the **smallest weighted error** (Section 4) is chosen. Ties are broken by the lowest feature index, then the lowest threshold, then polarity +1 before −1.

## 4. DotComBoost

**Initial public offering.** Every training example starts with **100 dollars**, stored as an integer.

**Weighted error.** In each round, the weighted error of a stump is the total dollars of the examples it misclassifies divided by the total dollars of all examples:

    ε = Σ_{i: h(x_i) ≠ y_i} w_i / Σ_i w_i.                             (2)

**Stopping.** If the chosen stump has ε = 0 or ε ≥ 0.5, training stops immediately and this stump is not added.

**Stump weight.** Otherwise, the stump's weight is

    α = ½ · ln((1 − ε) / ε).                                          (3)

**Revaluation.** Every example's dollars are updated as

    w_i ← w_i · exp(−α · y_i · h(x_i)),                               (4)

then **rounded down** to an integer (conservative accounting), and finally raised to **at least 1 dollar** (nobody is worthless, not even the easiest example).

**Irrational exuberance cap.** After the rounding, the median m of all current dollar values is computed, and every example worth more than 10·m is reduced to **⌊10·m⌋** dollars.

**Rounds.** Exactly **20 rounds** are run (unless training stops early).

**Final prediction.** The strong classifier predicts the sign of Σ_t α_t h_t(x). If the sum is exactly zero, it predicts **+1** (we are optimists).

## 5. Baseline

We compare against standard AdaBoost with real-valued weights initialized to 1/250 and renormalized to sum to one after every update, with no rounding and no cap, using the same stumps (Section 3), the same stopping rule and 20 rounds.

## 6. Results

Both classifiers are evaluated on the 107 test examples. The two test accuracies, together with the total dollars held by all training examples at the end of training (the "market capitalization"), are printed and saved to a results file.

| Method | Test accuracy | Final market cap |
| --- | --- | --- |
| AdaBoost (baseline) | 89.7 % | — |
| DotComBoost | 86.9 % | $302 |

DotComBoost trails AdaBoost by 2.8 points. More strikingly, its training set ends the year with a market capitalization of $302, down from an IPO value of $25,000 (250 examples at $100 each). This decline of 98.8% is, we are told by our investors, entirely in line with the sector.

## 7. Conclusion

We have shown that boosting survives the transition to integer currency. Future work will investigate stock-option weights that vest over four rounds, pending the outcome of our next funding round, which we expect any day now.
