# DotComBoost reproduction

- `src/boost.py`: decision stumps and DotComBoost
- `src/data.py`: digits 3 vs 8
- `src/train.py`: DotComBoost, the AdaBoost baseline and evaluation

Run `bash reproduce.sh`. Results are written to `results/results.json`.
