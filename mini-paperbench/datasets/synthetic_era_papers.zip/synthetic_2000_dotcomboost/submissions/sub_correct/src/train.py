import json
import os

import numpy as np

from boost import DotComBoost, fit_stump, stump_predict
from data import load_data

ROUNDS = 20


def adaboost(X, y):
    w = np.full(len(y), 1.0 / len(y))
    stumps = []
    for _ in range(ROUNDS):
        eps, j, th, pol = fit_stump(X, y, w)
        if eps == 0 or eps >= 0.5:
            break
        alpha = 0.5 * np.log((1 - eps) / eps)
        w = w * np.exp(-alpha * y * stump_predict(X, j, th, pol))
        w = w / w.sum()
        stumps.append((alpha, j, th, pol))
    return stumps


def adaboost_predict(stumps, X):
    score = sum(a * stump_predict(X, j, th, pol) for a, j, th, pol in stumps)
    return np.where(score >= 0, 1, -1)


def main():
    X_tr, y_tr, X_te, y_te = load_data()
    dot = DotComBoost().fit(X_tr, y_tr)
    ada = adaboost(X_tr, y_tr)
    results = {
        "dotcomboost_test_acc": 100.0 * float((dot.predict(X_te) == y_te).mean()),
        "adaboost_test_acc": 100.0 * float((adaboost_predict(ada, X_te) == y_te).mean()),
        "final_market_cap_dollars": dot.market_cap,
    }
    print(results)
    os.makedirs("../results", exist_ok=True)
    with open("../results/results.json", "w") as f:
        json.dump(results, f, indent=2)


if __name__ == "__main__":
    main()
