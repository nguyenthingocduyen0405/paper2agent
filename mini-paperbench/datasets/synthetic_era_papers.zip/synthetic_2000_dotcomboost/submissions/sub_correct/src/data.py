import numpy as np
from sklearn.datasets import load_digits


def load_data():
    digits = load_digits()
    keep = (digits.target == 3) | (digits.target == 8)
    X = digits.data[keep]
    y = np.where(digits.target[keep] == 8, 1, -1)
    return X[:250], y[:250], X[250:], y[250:]
