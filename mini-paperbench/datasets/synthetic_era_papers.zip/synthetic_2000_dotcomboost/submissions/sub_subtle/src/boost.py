import numpy as np

THRESHOLDS = np.arange(0.5, 15.0, 1.0)  # 0.5, 1.5, ..., 15.5


def stump_predict(X, j, th, pol):
    return np.where(X[:, j] > th, pol, -pol)


def fit_stump(X, y, w):
    total = w.sum()
    best = None
    for j in range(X.shape[1]):
        for th in THRESHOLDS:
            for pol in (-1, 1):
                pred = stump_predict(X, j, th, pol)
                err = w[pred != y].sum() / total
                if best is None or err < best[0]:
                    best = (err, j, th, pol)
    return best


class DotComBoost:
    def __init__(self, rounds=19, ipo_dollars=100, cap_multiple=10):
        self.rounds = rounds
        self.ipo_dollars = ipo_dollars
        self.cap_multiple = cap_multiple
        self.stumps = []
        self.market_cap = None

    def fit(self, X, y):
        w = np.full(len(y), self.ipo_dollars, dtype=np.int64)
        for _ in range(self.rounds):
            eps, j, th, pol = fit_stump(X, y, w)
            if eps == 0 or eps >= 0.5:
                break
            alpha = np.log((1 - eps) / eps)
            h = stump_predict(X, j, th, pol)
            w = np.round(w * np.exp(-alpha * y * h)).astype(np.int64)
            w = np.maximum(w, 1)
            cap = np.floor(self.cap_multiple * np.mean(w))
            w = np.minimum(w, cap).astype(np.int64)
            self.stumps.append((alpha, j, th, pol))
        self.market_cap = int(w.sum())
        return self

    def predict(self, X):
        score = sum(a * stump_predict(X, j, th, pol) for a, j, th, pol in self.stumps)
        return np.where(score > 0, 1, -1)
