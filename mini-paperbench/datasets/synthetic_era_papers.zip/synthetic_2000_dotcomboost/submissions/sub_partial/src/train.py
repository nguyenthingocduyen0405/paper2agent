from boost import DotComBoost
from data import load_data


def main():
    X_tr, y_tr, X_te, y_te = load_data()
    model = DotComBoost().fit(X_tr, y_tr)
    print(f"DotComBoost test accuracy: {100.0 * (model.predict(X_te) == y_te).mean():.1f}%")


if __name__ == "__main__":
    main()
