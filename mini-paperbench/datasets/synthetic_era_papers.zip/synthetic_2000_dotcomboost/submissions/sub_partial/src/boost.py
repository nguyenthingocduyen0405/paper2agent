import numpy as np

THRESHOLDS = np.arange(0.5, 16.0, 1.0)


def stump_predict(X, j, th, pol):
    return np.where(X[:, j] > th, pol, -pol)


def fit_stump(X, y, w):
    total = w.sum()
    best = None
    for j in range(X.shape[1]):
        for th in THRESHOLDS:
            for pol in (1, -1):
                pred = stump_predict(X, j, th, pol)
                err = w[pred != y].sum() / total
                if best is None or err < best[0]:
                    best = (err, j, th, pol)
    return best


class DotComBoost:
    def __init__(self, rounds=20):
        self.rounds = rounds
        self.stumps = []

    def fit(self, X, y):
        w = np.full(len(y), 100, dtype=np.int64)
        for _ in range(self.rounds):
            eps, j, th, pol = fit_stump(X, y, w)
            alpha = 0.5 * np.log((1 - eps) / eps)
            h = stump_predict(X, j, th, pol)
            w = np.floor(w * np.exp(-alpha * y * h)).astype(np.int64)
            self.stumps.append((alpha, j, th, pol))
        return self

    def predict(self, X):
        score = sum(a * stump_predict(X, j, th, pol) for a, j, th, pol in self.stumps)
        return np.where(score >= 0, 1, -1)
