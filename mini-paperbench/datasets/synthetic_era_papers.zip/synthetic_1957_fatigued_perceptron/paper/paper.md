# ON A SELF-ADJUSTING DISCRIMINATING MACHINE WITH RELAY FATIGUE

**Technical Memorandum No. 57-13**
**Laboratory for Thinking Machines, Building C (the one with the big fan)**

H. T. Tube and M. K. Relay

*Synthetic paper for judge evaluation, written in the style of the 1950s. The machine, the authors and the laboratory are fictional. The numbers come from the reference implementation (which, regrettably, does not contain a single vacuum tube).*

---

## I. INTRODUCTION

It has long been asked whether an electronic machine may be taught, as a child is taught, to tell one figure from another. In this memorandum we describe such a machine, constructed (on paper) at this Laboratory, which learns to discriminate between the hand-written figures NOUGHT and ONE.

The machine is of the self-adjusting type: its potentiometers are turned by small amounts whenever it gives a wrong answer. We have, however, observed a phenomenon not reported by earlier workers. After each adjustment the relays become *fatigued* and refuse to adjust again for a short time. Furthermore, the potentiometers drift whenever the operators leave for coffee. Rather than conceal these defects, we have made them part of the design. We call the result the *Fatigued Perceptron*.

## II. THE RETINA

Each figure is presented on a retina of 8 × 8 = 64 photocells. We obtain our figures from the modern "digits" collection of the scikit-learn library (a convenience not available in 1957), keeping only the figures NOUGHT (label 0) and ONE (label 1). This gives 360 figures, which we keep in their original order.

A photocell is LIT (value 1) if the brightness of its pixel is **8 or more** on the 0-to-16 scale, and DARK (value 0) otherwise. To the 64 photocells we add a 65th cell, the *bias cell*, which is **always LIT** (value 1).

The desired answer t is **+1 for ONE** and **−1 for NOUGHT**.

The **first 240 figures** form the training deck. The **last 120 figures** form the test deck. The decks are never shuffled; our card hopper is not equipped for randomness.

## III. THE MACHINE

The machine has 65 potentiometers w, one for each cell including the bias cell. All potentiometers are set to **zero** before the first presentation.

**Response.** When a figure x is presented, the machine computes the sum w · x. The relay closes, and the machine answers +1, only if the sum is **strictly greater than zero**. Otherwise (including a sum of exactly zero) the relay stays open and the machine answers −1.

## IV. THE ADJUSTMENT PROCEDURE

The training deck is presented card by card, in its original order. One pass through the deck is called a *reel*. For every presentation:

**(a) Fatigue.** If the relay is fatigued, it does not adjust, whatever the answer. One unit of fatigue is used up by this presentation.

**(b) Adjustment.** If the relay is not fatigued and the answer is wrong, the potentiometers are turned by a quarter turn:

    w ← w + 0.25 · t · x.                                         (1)

No adjustment is made when the answer is right.

**(c) End-stops.** Immediately after each adjustment, every potentiometer is limited to the range **−3 to +3** by its mechanical end-stops (values beyond are set to the nearest stop, on both sides).

**(d) Onset of fatigue.** After each adjustment, the relay is fatigued for the **next 2 presentations**.

**(e) Coffee drift.** The operators take coffee after every **100 presentations**, counted continuously from the start of training across all reels (that is, after presentations 100, 200, 300, …). During each coffee break the potentiometers drift toward zero: every w is multiplied by **0.9**.

**(f) Reels.** At most **7 reels** are run. Training stops early after any reel in which the machine gave no wrong answer at all. (Wrong answers given while fatigued count as wrong answers.)

## V. A CONVENTIONAL MACHINE FOR COMPARISON

For comparison we simulate a conventional machine of the earlier kind, without fatigue, end-stops or coffee drift, which adjusts by a full turn:

    w ← w + 1.0 · t · x   whenever the answer is wrong.

It uses the same retina, decks, order of presentation, zero starting position, response rule, maximum number of reels and early-stopping rule as the Fatigued Perceptron.

## VI. RESULTS

After training, each machine is shown the 120 cards of the test deck and the fraction of right answers is recorded. Both fractions, together with the total number of adjustments made by the Fatigued Perceptron, are printed on the teletype and saved to a results file.

| Machine | Right answers on test deck | Adjustments |
| --- | --- | --- |
| Conventional machine | 97.5 % | — |
| Fatigued Perceptron | 95.8 % | 9 |

The Fatigued Perceptron learned its task within two reels, making only nine adjustments in all, and was found to be within two cards of the conventional machine on the test deck. The remainder of its time was spent, we presume, recovering from those nine adjustments. In future work we intend to try the figures THREE and EIGHT, once the coffee budget is renewed.

## VII. ACKNOWLEDGEMENTS

The authors wish to thank the night operators, without whose coffee breaks Section IV(e) would not exist.
