import json
import os

import numpy as np

from data import load_decks
from machine import FatiguedPerceptron

MAX_REELS = 7


def train_fatigued(X, t):
    machine = FatiguedPerceptron()
    for reel in range(1, MAX_REELS + 1):
        order = np.random.default_rng(0).permutation(len(X))
        errors = 0
        for i in order:
            errors += machine.present(X[i], t[i])
        print(f"[Fatigued] reel {reel}: {errors} wrong answers")
        machine.tire()
        if errors == 0:
            break
    return machine


def train_conventional(X, t):
    w = np.zeros(X.shape[1])
    for _ in range(MAX_REELS):
        errors = 0
        for x, target in zip(X, t):
            answer = 1 if w @ x > 0 else -1
            if answer != target:
                w += 1.0 * target * x
                errors += 1
        if errors == 0:
            break
    return w


def right_answers(w, X, t):
    answers = np.where(X @ w > 0, 1, -1)
    return 100.0 * float((answers == t).mean())


def main():
    X_tr, t_tr, X_te, t_te = load_decks()
    machine = train_fatigued(X_tr, t_tr)
    w_conv = train_conventional(X_tr, t_tr)
    results = {
        "fatigued_test_acc": right_answers(machine.w, X_te, t_te),
        "conventional_test_acc": right_answers(w_conv, X_te, t_te),
        "adjustments": machine.adjustments,
    }
    print(results)
    os.makedirs("../results", exist_ok=True)
    with open("../results/results.json", "w") as f:
        json.dump(results, f, indent=2)


if __name__ == "__main__":
    main()
