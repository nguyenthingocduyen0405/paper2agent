# Fatigued Perceptron reproduction

Not implemented yet.
