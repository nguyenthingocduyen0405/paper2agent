import numpy as np


class FatiguedPerceptron:
    def __init__(self, n_inputs=65, increment=0.25, end_stop=3.0, fatigue=2,
                 coffee_every=100, drift=0.9):
        self.w = np.zeros(n_inputs)
        self.increment = increment
        self.end_stop = end_stop
        self.fatigue = fatigue
        self.coffee_every = coffee_every
        self.drift = drift
        self.rest = 0
        self.presentations = 0
        self.adjustments = 0

    def respond(self, x):
        return 1 if self.w @ x > 0 else -1

    def present(self, x, t):
        wrong = self.respond(x) != t
        if self.rest > 0:
            self.rest -= 1
        elif wrong:
            self.w += self.increment * t * x
            self.w = np.clip(self.w, -self.end_stop, self.end_stop)
            self.rest = self.fatigue
            self.adjustments += 1
        self.presentations += 1
        if self.presentations % self.coffee_every == 0:
            self.w *= self.drift
        return wrong
