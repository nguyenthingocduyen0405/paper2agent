# Fatigued Perceptron reproduction

- `src/machine.py`: the Fatigued Perceptron
- `src/data.py`: retina and decks
- `src/train.py`: training of both machines and evaluation

Run `bash reproduce.sh`. Results are written to `results/results.json`.
