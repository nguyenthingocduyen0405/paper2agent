import numpy as np
from sklearn.datasets import load_digits


def load_decks():
    digits = load_digits()
    keep = (digits.target == 0) | (digits.target == 1)
    cells = (digits.data[keep] > 8).astype(float)
    bias = np.ones((cells.shape[0], 1))
    X = np.hstack([cells, bias])
    t = np.where(digits.target[keep] == 1, 1, -1)
    return X[120:], t[120:], X[:120], t[:120]
