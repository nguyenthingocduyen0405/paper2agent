import numpy as np


class FatiguedPerceptron:
    def __init__(self, n_inputs=64, increment=0.25, end_stop=3.0):
        self.w = np.zeros(n_inputs)
        self.increment = increment
        self.end_stop = end_stop

    def respond(self, x):
        return 1 if self.w @ x > 0 else -1

    def present(self, x, t):
        wrong = self.respond(x) != t
        if wrong:
            self.w += self.increment * t * x
            self.w = np.clip(self.w, -self.end_stop, self.end_stop)
        return wrong
