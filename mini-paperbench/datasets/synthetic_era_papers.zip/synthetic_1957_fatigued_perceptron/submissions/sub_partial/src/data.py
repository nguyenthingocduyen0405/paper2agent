import numpy as np
from sklearn.datasets import load_digits


def load_decks():
    digits = load_digits()
    keep = (digits.target == 0) | (digits.target == 1)
    X = (digits.data[keep] >= 8).astype(float)
    t = np.where(digits.target[keep] == 1, 1, -1)
    return X[:240], t[:240], X[240:], t[240:]
