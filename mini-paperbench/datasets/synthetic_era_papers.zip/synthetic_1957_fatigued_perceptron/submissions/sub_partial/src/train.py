import numpy as np

from data import load_decks
from machine import FatiguedPerceptron

MAX_REELS = 7


def main():
    X_tr, t_tr, X_te, t_te = load_decks()
    machine = FatiguedPerceptron()
    for reel in range(1, MAX_REELS + 1):
        for x, target in zip(X_tr, t_tr):
            machine.present(x, target)
    answers = np.where(X_te @ machine.w > 0, 1, -1)
    print(f"Fatigued Perceptron right answers: {100.0 * (answers == t_te).mean():.1f}%")


if __name__ == "__main__":
    main()
