"""Shared checks: import a submission module, run every submission, check rubric/labels."""
import contextlib
import importlib
import io
import json
import os
import sys
import tempfile
from pathlib import Path

MODULES = ["data", "machine", "memory", "boost", "world", "survey", "nb", "train"]


def load(root, sub, module):
    src = str(Path(root) / "submissions" / sub / "src")
    for name in MODULES:
        sys.modules.pop(name, None)
    sys.path.insert(0, src)
    try:
        return importlib.import_module(module)
    finally:
        sys.path.remove(src)


def check_runs(root, subs):
    ok = True
    for sub in subs:
        train = load(root, sub, "train")
        cwd = os.getcwd()
        with tempfile.TemporaryDirectory() as tmp:
            os.makedirs(os.path.join(tmp, "src"))
            os.chdir(os.path.join(tmp, "src"))
            buf = io.StringIO()
            try:
                with contextlib.redirect_stdout(buf):
                    train.main()
                last = buf.getvalue().strip().splitlines()[-1]
                wrote = os.path.exists("../results/results.json")
                print(f"  [OK ] {sub:18s} runs; results file: {wrote}; {last}")
            except Exception as e:  # noqa: BLE001
                ok = False
                print(f"  [BAD] {sub:18s} failed: {e!r}")
            finally:
                os.chdir(cwd)
    return ok


def check_labels(root):
    root = Path(root)
    rubric = json.loads((root / "rubric.json").read_text())
    leaves, stack = [], [rubric]
    while stack:
        node = stack.pop()
        (stack.extend(node["sub_tasks"]) if node["sub_tasks"] else leaves.append(node))
    ids = {n["id"] for n in leaves}
    ok = all(n["task_category"] == "Code Development" for n in leaves)
    for f in sorted((root / "labels").glob("sub_*.json")):
        ok &= {x["leaf_id"] for x in json.loads(f.read_text())["labels"]} == ids
    print(f"  [{'OK ' if ok else 'BAD'}] {len(leaves)} leaves, all Code Development, every label file covers every leaf")
    return ok


def report(results):
    print("\nALL CHECKS PASSED" if all(results) else "\nSOME CHECKS FAILED")
    sys.exit(0 if all(results) else 1)
