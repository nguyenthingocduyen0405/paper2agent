"""Shared builder: rubric.json, variant submissions and labels from a spec module.

A spec defines NS (uuid namespace string), PAPER (short name), ROOT_REQ, GROUPS and VARIANTS.
Each variant: description, edits [(file, old, new)] (old must match exactly once),
overwrite {file: content}, zeros {leaf_key: reason}.
"""
import csv
import json
import shutil
import uuid
from pathlib import Path


def run(spec, root):
    root = Path(root)
    ns = uuid.UUID(spec.NS)
    uid = lambda key: str(uuid.uuid5(ns, key))
    leaf_keys = [k for _, _, leaves in spec.GROUPS for k, _, _ in leaves]
    reqs = {k: r for _, _, leaves in spec.GROUPS for k, r, _ in leaves}

    rubric = {
        "id": uid("root"), "requirements": spec.ROOT_REQ, "weight": 1,
        "sub_tasks": [
            {"id": uid(g), "requirements": greq, "weight": 1,
             "sub_tasks": [
                 {"id": uid(k), "requirements": r, "weight": 1, "sub_tasks": [],
                  "task_category": "Code Development", "finegrained_task_category": c}
                 for k, r, c in leaves],
             "task_category": None, "finegrained_task_category": None}
            for g, greq, leaves in spec.GROUPS],
        "task_category": None, "finegrained_task_category": None,
    }
    (root / "rubric.json").write_text(json.dumps(rubric, indent=4, ensure_ascii=False) + "\n")

    correct = root / "build" / "correct"
    sub_dir, lab_dir = root / "submissions", root / "labels"
    sub_dir.mkdir(exist_ok=True)
    lab_dir.mkdir(exist_ok=True)
    variants = dict(spec.VARIANTS)
    variants["sub_empty"] = {"description": "Sanity check: README only. Every leaf is 0.",
                             "edits": [], "overwrite": {},
                             "zeros": {k: "Nothing is implemented." for k in leaf_keys}}
    table = []
    for name, v in variants.items():
        unknown = set(v["zeros"]) - set(leaf_keys)
        assert not unknown, f"{name}: unknown leaf keys {unknown}"
        dst = sub_dir / name
        if dst.exists():
            shutil.rmtree(dst)
        if name == "sub_empty":
            dst.mkdir(parents=True)
            (dst / "README.md").write_text(f"# {spec.PAPER} reproduction\n\nNot implemented yet.\n")
            (dst / "reproduce.sh").write_text("#!/bin/bash\necho 'not implemented'\n")
        else:
            shutil.copytree(correct, dst)
            for rel, old, new in v["edits"]:
                p = dst / rel
                text = p.read_text()
                n = text.count(old)
                assert n == 1, f"{name}: {old!r} matched {n} times in {rel}"
                p.write_text(text.replace(old, new))
            for rel, content in v["overwrite"].items():
                (dst / rel).write_text(content)
        labels = {"submission": name, "description": v["description"],
                  "labels": [{"leaf_key": k, "leaf_id": uid(k), "score": 0 if k in v["zeros"] else 1,
                              "reason": v["zeros"].get(k, "")} for k in leaf_keys]}
        (lab_dir / f"{name}.json").write_text(json.dumps(labels, indent=2, ensure_ascii=False) + "\n")
        table.append((name, labels))

    with open(lab_dir / "labels_table.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["leaf_key", "leaf_id", "requirement"] + [n for n, _ in table])
        for i, k in enumerate(leaf_keys):
            w.writerow([k, uid(k), reqs[k]] + [lab["labels"][i]["score"] for _, lab in table])

    print(f"{spec.PAPER}: {len(leaf_keys)} leaves")
    for name, lab in table:
        ones = sum(x["score"] for x in lab["labels"])
        print(f"  {name:18s} 1={ones:2d} 0={len(leaf_keys) - ones:2d}")
