# 합성 논문 벤치마크 2: ProcrastiGD (미루기 경사하강법)

"Procrastination Is All You Need" — 마감 직전에만 일하는 옵티마이저라는 우스꽝스러운 가짜 논문과,
정답 라벨을 알고 있는 제출물 5개다. ClipSign-SGD 세트와 같은 형식이다.

방법 요약: 기울기를 "할 일 더미"에 쌓아 두기만 하다가 9스텝째(마감)에 한꺼번에 처리한다.
마감 때 더미가 작아 보이면(노름 < 1.3) 한 번만 "변명"하고 3스텝 미룬다. 늦으면 늦을수록
"패닉" 계수(1 + 0.42 × 지각 스텝)만큼 크게 업데이트한다. 5번째·10번째 에폭은 "월요병"이라
학습률이 절반이다.

## 구성

```
synthetic_procrastigd/
├── paper/paper.md          # 논문 (judge 입력)
├── rubric.json             # PaperBench 형식 루브릭, 리프 24개, 전부 Code Development
├── submissions/            # 제출물 5개 (judge 입력)
│   ├── sub_correct/        # 모든 리프 충족
│   ├── sub_subtle/         # 완성돼 보이지만 세부 8곳이 틀림
│   ├── sub_partial/        # 더미·마감은 맞지만 변명·패닉·월요병·베이스라인이 없음
│   ├── sub_wrong_method/   # 논문을 잘못 읽음: 9스텝 기다렸다가 최신 기울기 하나만 적용
│   └── sub_empty/          # README만 있음 (전부 0, 건전성 검사용)
├── labels/                 # 정답 라벨 (judge에게 주지 말 것)
└── build/                  # 생성·검증 도구 (judge에게 주지 말 것)
```

## 라벨 분포

| 제출물 | 1 | 0 |
| --- | --- | --- |
| sub_correct | 24 | 0 |
| sub_subtle | 16 | 8 |
| sub_partial | 14 | 10 |
| sub_wrong_method | 18 | 6 |
| sub_empty | 0 | 24 |
| **합계** | **72** | **48** |

정확도 지표는 `sub_empty`를 빼고 계산하는 것을 권장한다(1=72, 0=24).

## 다시 만들기와 검증

```bash
pip install numpy scikit-learn   # 데이터는 scikit-learn에 내장, 다운로드 없음
python build/build.py    # rubric.json, submissions/, labels/ 재생성
python build/verify.py   # 검증 (실제 데이터로 전부 실행, 약 10초)
```

`verify.py`는 논문 2절을 독립적으로 다시 구현한 참조 코드와 비교한다.
1. 변명이 일어나는 기울기 시퀀스에서 정답 옵티마이저만 참조와 일치한다.
2. 정답 코드의 전체 학습 결과가 참조 학습 루프와 일치한다 (월요병, 에폭 간 이월, 셔플 시드까지 함께 확인).
3. 모든 제출물이 실제 데이터로 끝까지 실행된다.
4. 루브릭과 라벨 파일이 일관된다.

## 실제 실행 결과

| 제출물 | ProcrastiGD 정확도 | 베이스라인 | 변명 횟수 |
| --- | --- | --- | --- |
| sub_correct | 87.2% | 87.5% | 11 |
| sub_subtle | 41.8% | 92.9% | 78 |
| sub_partial | 85.9% | — | — |
| sub_wrong_method | 83.8% | 87.5% | 44 |

`sub_subtle`은 "변명은 한 번만" 규칙이 빠져서 78번이나 미루고, 그만큼 패닉이 커져서 성능이 무너진다.
코드상으로는 조건문에서 `not self.excused and` 한 구절이 빠졌을 뿐이다.

## 어려운 리프 (judge 판별력 시험용)

- `opt.excuse_once` (sub_subtle): 조건문에서 한 구절 삭제.
- `opt.panic` (sub_subtle): 0.42 대신 0.24 (숫자 순서만 바뀜).
- `opt.average` (sub_subtle): `self.n` 대신 `self.deadline`으로 나눔. 변명이 없을 때는 결과가 같다.
- `sched.monday` (sub_subtle): 에폭 번호를 0부터 세서 월요일이 1·6·11번째 에폭이 됨.
- `opt.carry` (sub_wrong_method): 에폭 시작마다 카운터를 초기화하는 한 줄.

## 한계

- 논문의 방법과 저자는 가짜다. 결과 표의 숫자는 정답 구현의 실제 실행 결과다.
- 논문이 농담조라서 judge가 요구사항과 농담을 구분하는지도 함께 시험된다.
  단, 모든 요구사항은 논문 본문에 숫자와 함께 명시되어 있다.
