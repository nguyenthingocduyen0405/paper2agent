import numpy as np


class ProcrastiGD:
    def __init__(self, params, lr=0.77, deadline=9, excuse_threshold=1.3,
                 excuse_steps=3, panic_rate=0.42):
        self.params = params
        self.lr = lr
        self.deadline = deadline
        self.excuse_threshold = excuse_threshold
        self.excuse_steps = excuse_steps
        self.panic_rate = panic_rate
        self.latest = None
        self.n = 0
        self.due = deadline
        self.excused = False
        self.excuses_used = 0
        self.updates_done = 0

    def step(self, grads):
        self.latest = {k: g.copy() for k, g in grads.items()}
        self.n += 1
        if self.n < self.due:
            return
        norm = np.sqrt(sum(np.sum(g ** 2) for g in self.latest.values()))
        if not self.excused and norm < self.excuse_threshold:
            self.due += self.excuse_steps
            self.excused = True
            self.excuses_used += 1
            return
        panic = 1 + self.panic_rate * (self.n - self.deadline)
        for k in self.params:
            self.params[k] -= self.lr * panic * self.latest[k]
        self.n = 0
        self.due = self.deadline
        self.excused = False
        self.updates_done += 1
