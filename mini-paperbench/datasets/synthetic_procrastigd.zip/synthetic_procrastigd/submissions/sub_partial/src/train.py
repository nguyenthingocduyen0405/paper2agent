import numpy as np

from data import load_data
from model import LogisticRegression
from procrastigd import ProcrastiGD

SEED = 13
EPOCHS = 12
BATCH_SIZE = 30
LR = 0.77


def main():
    X_tr, y_tr, X_te, y_te = load_data()
    rng = np.random.default_rng(SEED)
    model = LogisticRegression()
    opt = ProcrastiGD(model.params, lr=LR)
    for epoch in range(1, EPOCHS + 1):
        order = rng.permutation(len(X_tr))
        for i in range(0, len(X_tr), BATCH_SIZE):
            idx = order[i:i + BATCH_SIZE]
            _, grads = model.loss_and_grads(X_tr[idx], y_tr[idx])
            opt.step(grads)
        opt.forget()
        print(f"epoch {epoch} done")
    print(f"ProcrastiGD test acc: {model.accuracy(X_te, y_te):.2f}")


if __name__ == "__main__":
    main()
