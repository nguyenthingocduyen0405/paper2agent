import numpy as np


class ProcrastiGD:
    def __init__(self, params, lr=0.77, deadline=9):
        self.params = params
        self.lr = lr
        self.deadline = deadline
        self.pile = {k: np.zeros_like(v) for k, v in params.items()}
        self.n = 0

    def step(self, grads):
        for k, g in grads.items():
            self.pile[k] += g
        self.n += 1
        if self.n < self.deadline:
            return
        for k in self.params:
            self.params[k] -= self.lr * self.pile[k] / self.n
        self.forget()

    def forget(self):
        for k in self.pile:
            self.pile[k][:] = 0.0
        self.n = 0
