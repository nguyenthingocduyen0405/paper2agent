import numpy as np
from sklearn.datasets import load_digits


def load_data():
    digits = load_digits()
    X = digits.data / 16.0
    y = digits.target
    order = np.random.default_rng(0).permutation(len(X))
    X, y = X[order], y[order]
    return X[:1500], y[:1500], X[1500:], y[1500:]
