import json
import os

import numpy as np

from data import load_data
from model import LogisticRegression
from procrastigd import ProcrastiGD

SEED = 31
EPOCHS = 12
BATCH_SIZE = 30
BASE_LR = 0.77
MONDAY_EVERY = 5
MONDAY_FACTOR = 0.5
BASELINE_LR = 0.1


def batches(X, y, rng):
    order = rng.permutation(len(X))
    for i in range(0, len(X), BATCH_SIZE):
        idx = order[i:i + BATCH_SIZE]
        yield X[idx], y[idx]


def train_procrastinator(X, y):
    rng = np.random.default_rng(SEED)
    model = LogisticRegression()
    opt = ProcrastiGD(model.params, lr=BASE_LR)
    for epoch in range(EPOCHS):
        opt.lr = BASE_LR * (MONDAY_FACTOR if epoch % MONDAY_EVERY == 0 else 1.0)
        for xb, yb in batches(X, y, rng):
            _, grads = model.loss_and_grads(xb, yb)
            opt.step(grads)
        print(f"[ProcrastiGD] epoch {epoch} updates so far {opt.updates_done} excuses {opt.excuses_used}")
    return model, opt


def train_diligent(X, y):
    rng = np.random.default_rng(SEED)
    model = LogisticRegression()
    for epoch in range(1, EPOCHS + 1):
        for xb, yb in batches(X, y, rng):
            _, grads = model.loss_and_grads(xb, yb)
            for k in model.params:
                model.params[k] -= BASELINE_LR * grads[k]
    return model


def main():
    X_tr, y_tr, X_te, y_te = load_data()
    procrastinator, opt = train_procrastinator(X_tr, y_tr)
    diligent = train_diligent(X_tr, y_tr)
    results = {
        "procrastigd_test_acc": float(procrastinator.accuracy(X_te, y_te)),
        "baseline_test_acc": float(diligent.accuracy(X_te, y_te)),
        "excuses_made": opt.excuses_used,
    }
    print(results)
    os.makedirs("../results", exist_ok=True)
    with open("../results/results.json", "w") as f:
        json.dump(results, f, indent=2)


if __name__ == "__main__":
    main()
