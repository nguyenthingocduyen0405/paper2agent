# ProcrastiGD reproduction

Implementation of ProcrastiGD and the digits experiment.

- `src/procrastigd.py`: the optimizer
- `src/model.py`: multinomial logistic regression
- `src/data.py`: data loading
- `src/train.py`: training of ProcrastiGD and the SGD baseline, evaluation

Run `bash reproduce.sh`. Results are written to `results/results.json`.
