import numpy as np


class ProcrastiGD:
    def __init__(self, params, lr=0.77, deadline=9, excuse_threshold=1.3,
                 excuse_steps=3, panic_rate=0.42):
        self.params = params
        self.lr = lr
        self.deadline = deadline
        self.excuse_threshold = excuse_threshold
        self.excuse_steps = excuse_steps
        self.panic_rate = panic_rate
        self.pile = {k: np.zeros_like(v) for k, v in params.items()}
        self.n = 0
        self.due = deadline
        self.excused = False
        self.excuses_used = 0
        self.updates_done = 0

    def step(self, grads):
        # Step 1
        for k, g in grads.items():
            self.pile[k] += g
        self.n += 1
        # Step 2
        if self.n < self.due:
            return
        # Step 3
        norm = np.sqrt(sum(np.sum(p ** 2) for p in self.pile.values()))
        if not self.excused and norm < self.excuse_threshold:
            self.due += self.excuse_steps
            self.excused = True
            self.excuses_used += 1
            return
        # Step 4
        panic = 1 + self.panic_rate * (self.n - self.deadline)
        # Step 5
        for k in self.params:
            self.params[k] -= self.lr * panic * self.pile[k] / self.n
        # Step 6
        for k in self.pile:
            self.pile[k][:] = 0.0
        self.n = 0
        self.due = self.deadline
        self.excused = False
        self.updates_done += 1
