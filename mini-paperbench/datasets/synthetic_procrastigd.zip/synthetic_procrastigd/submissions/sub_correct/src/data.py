from sklearn.datasets import load_digits


def load_data():
    digits = load_digits()
    X = digits.data / 16.0
    y = digits.target
    return X[:1500], y[:1500], X[1500:], y[1500:]
