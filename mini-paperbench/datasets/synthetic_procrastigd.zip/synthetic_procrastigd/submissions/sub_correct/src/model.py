import numpy as np


class LogisticRegression:
    def __init__(self, n_in=64, n_out=10):
        self.params = {"W": np.zeros((n_in, n_out)), "b": np.zeros(n_out)}

    def logits(self, X):
        return X @ self.params["W"] + self.params["b"]

    def loss_and_grads(self, X, y):
        z = self.logits(X)
        z = z - z.max(axis=1, keepdims=True)
        p = np.exp(z)
        p /= p.sum(axis=1, keepdims=True)
        n = X.shape[0]
        loss = -np.log(p[np.arange(n), y] + 1e-12).mean()
        d = p
        d[np.arange(n), y] -= 1.0
        d /= n
        return loss, {"W": X.T @ d, "b": d.sum(axis=0)}

    def accuracy(self, X, y):
        return 100.0 * (self.logits(X).argmax(axis=1) == y).mean()
