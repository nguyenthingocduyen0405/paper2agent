# Procrastination Is All You Need: Deadline-Driven Gradient Descent

*A. Later, B. Tomorrow, C. Snooze — Department of Things That Were Due Yesterday*

*Synthetic paper for judge evaluation. The method and the authors are fictional. The numbers come from the reference implementation.*

## Abstract

Every graduate student knows that no real work happens until a deadline is near. We bring this
insight to optimization. ProcrastiGD collects gradients in a *to-do pile* and does nothing with
them until a deadline arrives. If the pile looks small at the deadline, the optimizer makes an
excuse and postpones once. When it finally works, it works in a *panic*, proportional to how late
it is. On a handwritten digit task, ProcrastiGD comes within half a point of a diligent baseline
that updates at every step, while making about nine times fewer updates and spending the rest of
its time, presumably, on social media.

## 1. Introduction

Standard SGD is the diligent student: it updates the parameters after every mini-batch. This is
admirable but exhausting. We ask a simple question: what if the optimizer just did everything the
night before? We formalize three well-known human behaviors: (i) postponing work until a
deadline, (ii) making one excuse when the work seems small, and (iii) panicking when late.

## 2. Method

ProcrastiGD keeps three pieces of state, all shared across the whole model:

- a **to-do pile** P with one array per parameter, initially all zeros,
- a **step counter** n (the number of gradients currently in the pile), initially 0,
- an **excuse flag** that records whether an excuse has already been used for the current pile.

At every training step with gradient g (one array per parameter):

**Step 1: Add to the pile.** P ← P + g. The pile is a plain **sum**, not an average or a moving
average. Then n ← n + 1. On a step that is not a deadline, the parameters are **not changed**.

**Step 2: Check the deadline.** The deadline is reached when n equals the current due count. The
due count is **9** for a fresh pile.

**Step 3: Maybe make an excuse.** At a deadline, compute the global L2 norm of the pile over all
parameters together, ‖P‖ = sqrt(Σ over all parameters and entries of P²). If ‖P‖ < **1.3** and no
excuse has been used for the current pile, the optimizer says "this is tiny, I'll do it later":
the due count is increased by exactly **3** steps and the parameters are not changed. Only **one**
excuse is allowed per pile. At the postponed deadline the update happens no matter how small the
pile is.

**Step 4: Panic.** When the update finally happens, the panic factor is

    panic = 1 + 0.42 · (n − 9),                                  (1)

so panic = 1 when the work is on time (n = 9) and panic = 2.26 after an excuse (n = 12).

**Step 5: Do everything at once.** The pile is averaged over the number of gradients it contains,
and the parameters are updated:

    θ ← θ − η · panic · (P / n).                                 (2)

Note that n is the actual number of gradients in the pile (12 after an excuse), not the constant 9.

**Step 6: Forget about it.** After the update, the pile is emptied (P ← 0), n ← 0, the due count
returns to 9, and the excuse flag is cleared.

**No end-of-epoch cleanup.** Procrastination knows no epoch boundaries. The pile, the counter and
the excuse flag are **not** reset or applied at the end of an epoch; unfinished work simply carries
over into the next epoch. Whatever is left in the pile when training ends is never done.

### 2.1 Learning rate and Monday blues

The base learning rate is η = **0.77**. Every fifth epoch is a *Monday*: during epochs 5 and 10
(1-based epoch numbers divisible by 5) the learning rate is halved to 0.385. It returns to 0.77 at
the start of the next epoch.

## 3. Experimental Setup

**Data.** We use the scikit-learn handwritten digits dataset (`load_digits`, 1,797 images of 8×8
pixels, 10 classes). Pixel values are divided by 16 so that they lie in [0, 1]. Without any
shuffling, the **first 1,500** samples form the training set and the **last 297** samples form the
test set.

**Model.** Multinomial logistic regression: a single linear layer from 64 inputs to 10 outputs with
a bias, followed by softmax. The loss is the cross-entropy averaged over the mini-batch. All weights
and biases are initialized to **zero** ("a blank to-do list").

**Training.** Batch size **30**, **12** epochs. At the start of every epoch the training samples are
shuffled with a NumPy random generator created once with seed **13** (we are not superstitious).

**Baseline (the diligent student).** The same model, initialization, data, batch size, number of
epochs and shuffling seed, trained with plain mini-batch SGD with a constant learning rate of **0.1**
that updates the parameters at every step.

**Evaluation.** After training, test accuracy on the 297 test samples is computed for both
ProcrastiGD and the baseline. Both accuracies and the total number of excuses ProcrastiGD made
are printed and saved to a results file.

## 4. Results

| Optimizer | Updates per epoch | Test accuracy (%) | Excuses made |
| --- | --- | --- | --- |
| Diligent SGD (baseline) | 50 | 87.5 | 0 (suspicious) |
| ProcrastiGD | ≈ 5.3 | 87.2 | 11 |

ProcrastiGD is only 0.3 points behind the baseline while doing about one ninth of the updates.
We consider the missing 0.3 points a reasonable price for eleven excuses. Reviewers asked us to
run more seeds. We will do it later.

## 5. Limitations

ProcrastiGD has not been tested on large models, mostly because we kept postponing it. Broader
impact: this paper may encourage bad habits in students. We will address this concern next week.
