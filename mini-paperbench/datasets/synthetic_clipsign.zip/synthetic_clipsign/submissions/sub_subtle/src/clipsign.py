import torch
from torch.optim import Optimizer


class ClipSignSGD(Optimizer):
    def __init__(self, params, lr=0.004, beta=0.73, weight_decay=0.0013, tau_scale=0.37):
        defaults = dict(lr=lr, beta=beta, weight_decay=weight_decay, tau_scale=tau_scale)
        super().__init__(params, defaults)

    @torch.no_grad()
    def step(self):
        for group in self.param_groups:
            lr, beta = group["lr"], group["beta"]
            wd, tau_scale = group["weight_decay"], group["tau_scale"]
            for p in group["params"]:
                if p.grad is None:
                    continue
                # Eq. (1)
                g = p.grad.clone()
                # Eq. (2)
                tau = tau_scale * g.abs().max()
                # Eq. (3)
                s = torch.sign(g)
                s[g.abs() <= tau] = 0.0
                # Eq. (4)
                state = self.state[p]
                if "m" not in state:
                    state["m"] = torch.zeros_like(p)
                m = state["m"]
                m.mul_(beta).add_(s)
                # Eq. (5)
                p.mul_(1 - lr * wd)
                p.add_(m, alpha=-lr)
