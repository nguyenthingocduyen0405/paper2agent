import torch
from torch.optim import Optimizer


class ClipSignSGD(Optimizer):
    def __init__(self, params, lr=0.004, beta=0.73, weight_decay=0.0013):
        defaults = dict(lr=lr, beta=beta, weight_decay=weight_decay)
        super().__init__(params, defaults)

    @torch.no_grad()
    def step(self):
        for group in self.param_groups:
            lr, beta, wd = group["lr"], group["beta"], group["weight_decay"]
            for p in group["params"]:
                if p.grad is None:
                    continue
                g = p.grad
                state = self.state[p]
                if "m" not in state:
                    state["m"] = torch.zeros_like(p)
                m = state["m"]
                m.mul_(beta).add_(g, alpha=1 - beta)
                p.mul_(1 - lr * wd)
                p.add_(torch.sign(m), alpha=-lr)
