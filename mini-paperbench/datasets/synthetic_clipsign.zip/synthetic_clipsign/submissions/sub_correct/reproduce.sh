#!/bin/bash
set -e
pip install -r requirements.txt
cd src
python train.py
