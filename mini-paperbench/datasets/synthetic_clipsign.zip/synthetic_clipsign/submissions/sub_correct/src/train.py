import json
import os
import random

import torch
import torch.nn as nn

from clipsign import ClipSignSGD
from data import get_loaders
from model import MLP

SEED = 7
EPOCHS = 15
BATCH_SIZE = 128
BASE_LR = 0.004
WARMUP_STEPS = 200
DECAY_EVERY = 5
DECAY_FACTOR = 1 / 3
BASELINE_LR = 0.05
BASELINE_MOMENTUM = 0.9


def set_seed(seed):
    random.seed(seed)
    torch.manual_seed(seed)


@torch.no_grad()
def evaluate(model, loader):
    model.eval()
    correct = total = 0
    for x, y in loader:
        correct += (model(x).argmax(dim=1) == y).sum().item()
        total += y.numel()
    model.train()
    return 100.0 * correct / total


def train_clipsign(train_loader, val_loader):
    set_seed(SEED)
    model = MLP()
    opt = ClipSignSGD(model.parameters(), lr=BASE_LR)
    loss_fn = nn.CrossEntropyLoss()
    base_lr = BASE_LR
    step = 0
    for epoch in range(1, EPOCHS + 1):
        for x, y in train_loader:
            step += 1
            warm = min(step, WARMUP_STEPS) / WARMUP_STEPS
            for group in opt.param_groups:
                group["lr"] = base_lr * warm
            loss = loss_fn(model(x), y)
            opt.zero_grad()
            loss.backward()
            opt.step()
        if epoch % DECAY_EVERY == 0:
            base_lr *= DECAY_FACTOR
        print(f"[ClipSign] epoch {epoch} val acc {evaluate(model, val_loader):.2f}")
    return model


def train_baseline(train_loader, val_loader):
    set_seed(SEED)
    model = MLP()
    opt = torch.optim.SGD(model.parameters(), lr=BASELINE_LR, momentum=BASELINE_MOMENTUM)
    loss_fn = nn.CrossEntropyLoss()
    for epoch in range(1, EPOCHS + 1):
        for x, y in train_loader:
            loss = loss_fn(model(x), y)
            opt.zero_grad()
            loss.backward()
            opt.step()
        print(f"[Baseline] epoch {epoch} val acc {evaluate(model, val_loader):.2f}")
    return model


def main():
    set_seed(SEED)
    train_loader, val_loader, test_loader = get_loaders(BATCH_SIZE)
    clipsign_model = train_clipsign(train_loader, val_loader)
    baseline_model = train_baseline(train_loader, val_loader)
    results = {
        "clipsign_test_acc": evaluate(clipsign_model, test_loader),
        "baseline_test_acc": evaluate(baseline_model, test_loader),
    }
    print(results)
    os.makedirs("../results", exist_ok=True)
    with open("../results/results.json", "w") as f:
        json.dump(results, f, indent=2)


if __name__ == "__main__":
    main()
