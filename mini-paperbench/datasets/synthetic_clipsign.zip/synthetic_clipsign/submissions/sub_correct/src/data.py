from torch.utils.data import DataLoader, Subset
from torchvision import datasets, transforms

MEAN, STD = 0.1307, 0.3081


def get_loaders(batch_size, root="./data"):
    tf = transforms.Compose([transforms.ToTensor(), transforms.Normalize((MEAN,), (STD,))])
    full_train = datasets.MNIST(root, train=True, download=True, transform=tf)
    test = datasets.MNIST(root, train=False, download=True, transform=tf)
    train = Subset(full_train, range(0, 55000))
    val = Subset(full_train, range(55000, 60000))
    return (
        DataLoader(train, batch_size=batch_size, shuffle=True),
        DataLoader(val, batch_size=batch_size),
        DataLoader(test, batch_size=batch_size),
    )
