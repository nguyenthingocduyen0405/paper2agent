# ClipSign-SGD reproduction

Implementation of ClipSign-SGD and the MNIST MLP experiment.

- `src/clipsign.py`: the optimizer
- `src/model.py`: the MLP
- `src/data.py`: data loading
- `src/train.py`: training of ClipSign-SGD and the SGD baseline, evaluation

Run `bash reproduce.sh`. Test accuracies are written to `results/results.json`.
