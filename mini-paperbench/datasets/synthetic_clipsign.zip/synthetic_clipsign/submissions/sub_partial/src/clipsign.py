import torch
from torch.optim import Optimizer


class ClipSignSGD(Optimizer):
    def __init__(self, params, lr=0.004, beta=0.73, tau_scale=0.37):
        defaults = dict(lr=lr, beta=beta, tau_scale=tau_scale)
        super().__init__(params, defaults)

    @torch.no_grad()
    def step(self):
        for group in self.param_groups:
            lr, beta, tau_scale = group["lr"], group["beta"], group["tau_scale"]
            for p in group["params"]:
                if p.grad is None:
                    continue
                g = p.grad
                tau = tau_scale * g.abs().mean()
                s = torch.sign(g)
                s[g.abs() < tau] = 0.0
                state = self.state[p]
                if "m" not in state:
                    state["m"] = torch.zeros_like(p)
                m = state["m"]
                m.mul_(beta).add_(s, alpha=1 - beta)
                p.add_(m, alpha=-lr)
