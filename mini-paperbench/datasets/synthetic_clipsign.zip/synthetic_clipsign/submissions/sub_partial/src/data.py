from torch.utils.data import DataLoader
from torchvision import datasets, transforms


def get_loaders(batch_size, root="./data"):
    tf = transforms.Compose([transforms.ToTensor()])
    train = datasets.MNIST(root, train=True, download=True, transform=tf)
    test = datasets.MNIST(root, train=False, download=True, transform=tf)
    return (
        DataLoader(train, batch_size=batch_size, shuffle=True),
        DataLoader(test, batch_size=batch_size),
    )
