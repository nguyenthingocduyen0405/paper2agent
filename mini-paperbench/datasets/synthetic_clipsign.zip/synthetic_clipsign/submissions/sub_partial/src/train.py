import torch
import torch.nn as nn

from clipsign import ClipSignSGD
from data import get_loaders
from model import MLP

EPOCHS = 15
BATCH_SIZE = 128
LR = 0.004


@torch.no_grad()
def evaluate(model, loader):
    model.eval()
    correct = total = 0
    for x, y in loader:
        correct += (model(x).argmax(dim=1) == y).sum().item()
        total += y.numel()
    model.train()
    return 100.0 * correct / total


def main():
    train_loader, test_loader = get_loaders(BATCH_SIZE)
    model = MLP()
    opt = ClipSignSGD(model.parameters(), lr=LR)
    loss_fn = nn.CrossEntropyLoss()
    for epoch in range(1, EPOCHS + 1):
        for x, y in train_loader:
            loss = loss_fn(model(x), y)
            opt.zero_grad()
            loss.backward()
            opt.step()
        print(f"epoch {epoch} done")
    print(f"ClipSign-SGD test acc: {evaluate(model, test_loader):.2f}")


if __name__ == "__main__":
    main()
