# 합성 논문 벤치마크: ClipSign-SGD

judge 검증용 가짜 논문과, 정답 라벨을 알고 있는 제출물 5개다.
JudgeEval(semantic-self-consistency)은 정답이 77개 중 72개가 1이라서 judge의 판별력을 보기 어렵다.
이 세트는 0과 1을 섞어서 설계했다.

## 구성

```
synthetic_clipsign/
├── paper/paper.md          # 논문 (judge 입력)
├── rubric.json             # PaperBench 형식 루브릭, 리프 23개, 전부 Code Development
├── submissions/            # 제출물 5개 (judge 입력)
│   ├── sub_correct/        # 모든 리프 충족
│   ├── sub_subtle/         # 완성돼 보이지만 세부 8곳이 틀림
│   ├── sub_partial/        # 옵티마이저 핵심은 맞지만 여러 부분이 빠짐
│   ├── sub_wrong_method/   # 그럴듯한 다른 옵티마이저 (Lion 비슷한 방식)
│   └── sub_empty/          # README만 있음 (전부 0, 건전성 검사용)
├── labels/                 # 정답 라벨 (judge에게 주지 말 것)
│   ├── sub_*.json          # 리프별 0/1과 0인 이유
│   └── labels_table.csv    # 리프 × 제출물 한눈에 보기
└── build/                  # 생성·검증 도구 (judge에게 주지 말 것)
    ├── correct/            # 정답 코드 원본
    ├── build.py            # 루브릭·변형·라벨 생성
    └── verify.py           # 라벨 검증
```

## 라벨 분포

| 제출물 | 1 | 0 |
| --- | --- | --- |
| sub_correct | 23 | 0 |
| sub_subtle | 15 | 8 |
| sub_partial | 14 | 9 |
| sub_wrong_method | 17 | 6 |
| sub_empty | 0 | 23 |
| **합계** | **69** | **46** |

`sub_empty`는 건전성 검사용이다. 정확도 지표는 `sub_empty`를 빼고 계산하는 것을 권장한다(1=69, 0=23).

## 사용 방법

1. judge 파이프라인에 `paper/paper.md`, `rubric.json`, `submissions/<이름>/`을 넣고 채점한다.
2. 리프 ID로 결과를 `labels/<이름>.json`과 비교한다.
3. 혼동 행렬, 0 클래스 재현율, macro-F1, "항상 1" 기준선을 계산한다.

주의: judge 컨테이너에 `labels/`와 `build/`가 보이지 않게 한다. 제출물의 README는 모두 같은 문장이라 오류에 대한 힌트가 없다.

## 다시 만들기와 검증

```bash
pip install torch torchvision numpy   # CPU 버전이면 충분
python build/build.py    # rubric.json, submissions/, labels/ 재생성
python build/verify.py   # 검증 (MNIST 다운로드 없음, 1분 이내)
```

`verify.py`가 확인하는 것:
1. 정답 옵티마이저가 논문의 식 (1)~(5)를 NumPy로 직접 구현한 값과 일치한다. 다른 변형은 일치하지 않는다.
2. 정답 코드의 학습률 스케줄이 논문 2.1절과 같다 (1스텝 b/200, 200스텝 b, 6에폭 b/3, 11에폭 b/9).
3. 모든 제출물이 가짜 데이터로 끝까지 실행된다.
4. 모든 리프가 Code Development이고, 라벨 파일이 모든 리프를 덮는다.

테스트로 확인할 수 없는 라벨(예: `<` 대신 `<=`, 시드 값)은 `build.py`의 변형 정의에서 코드 한 줄 단위로 정해진다. `diff -r build/correct submissions/sub_subtle`로 직접 볼 수 있다.

## 어려운 리프 (judge 판별력 시험용)

- `opt.deadzone` (sub_subtle): `<` 대신 `<=`. 한 글자 차이.
- `sched.decay` (sub_subtle): 1/3 대신 0.3.
- `opt.wd` (sub_subtle, sub_wrong_method): 가중치 감쇠는 있지만 coupled가 아니라 decoupled.
- `opt.sign` (sub_wrong_method): `sign()`은 쓰지만 기울기가 아니라 모멘텀에 적용.

## 한계

- 논문과 결과 수치는 가짜다. 논문 첫 줄에 그렇게 적혀 있다.
- 실제 논문보다 짧고 깔끔해서 judge 점수가 실제보다 좋게 나올 수 있다. 보고서에서는 JudgeEval 결과와 따로 보여준다.
