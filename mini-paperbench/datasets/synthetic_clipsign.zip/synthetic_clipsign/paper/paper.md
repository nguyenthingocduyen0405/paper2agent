# ClipSign-SGD: Dead-Zone Sign Updates with Smoothed Momentum

*Synthetic paper for judge evaluation. The method and the reported numbers are fictional.*

## Abstract

We propose ClipSign-SGD, a sign-based optimizer that ignores small gradient components. For each parameter tensor, gradient components whose magnitude falls below a relative threshold are set to zero, and the remaining components are replaced by their sign. The resulting ternary vector is smoothed with an exponential moving average and used as the update direction. On MNIST with a small MLP, ClipSign-SGD matches SGD with momentum while using a learning rate an order of magnitude smaller.

## 1. Introduction

Sign-based optimizers such as signSGD use only the sign of each gradient component. This makes them robust to gradient scale, but it also gives equal weight to tiny, noisy components. ClipSign-SGD adds a *dead zone*: components that are small relative to the rest of the tensor do not move the parameter at all. We combine this with a smoothed momentum buffer, a short learning-rate warmup, and a step decay schedule.

## 2. Method

Let θ be one parameter tensor and g its gradient at the current step. ClipSign-SGD applies the following steps to every parameter tensor independently, in this order.

**Step 1: Coupled weight decay.** Weight decay is added to the gradient *before* any other step:

    g ← g + λ θ,   with λ = 0.0013.                         (1)

This is coupled (L2-style) weight decay. It is not decoupled weight decay applied to the parameters.

**Step 2: Relative dead-zone threshold.** The threshold is computed per tensor from the gradient after Step 1:

    τ = 0.37 · mean_i |g_i|.                                  (2)

The mean is taken over all components of the tensor.

**Step 3: Ternary sign vector.** For each component i:

    s_i = 0          if |g_i| < τ   (strictly less than)
    s_i = sign(g_i)  otherwise.                               (3)

A component with |g_i| exactly equal to τ is not zeroed.

**Step 4: Smoothed momentum.** The momentum buffer m is an exponential moving average of s:

    m ← β · m + (1 − β) · s,   with β = 0.73.                 (4)

The buffer m is initialized to zeros before the first step. Note that m averages the ternary vector s, not the raw gradient g.

**Step 5: Parameter update.**

    θ ← θ − η · m.                                            (5)

The update uses m directly. No sign or normalization is applied to m.

### 2.1 Learning-rate schedule

The base learning rate is η₀ = 0.004. During the first 200 optimizer steps the learning rate increases linearly from η₀/200 at step 1 to η₀ at step 200. After warmup, the learning rate is multiplied by exactly 1/3 at the end of every 5 epochs (after epochs 5 and 10 in a 15-epoch run).

## 3. Experimental Setup

**Data.** We use MNIST. Images are converted to tensors and normalized with mean 0.1307 and standard deviation 0.3081. The *last* 5,000 images of the 60,000-image training set are held out as a validation set; the first 55,000 are used for training. The official 10,000-image test set is used for final evaluation.

**Model.** A multilayer perceptron with layer sizes 784 → 256 → 128 → 10 and ReLU activations after the two hidden layers. Images are flattened to 784-dimensional vectors.

**Training.** Batch size 128, 15 epochs, cross-entropy loss. All runs use random seed 7 for PyTorch and Python's random module.

**Baseline.** The same model is trained with PyTorch's SGD with momentum 0.9 and a constant learning rate of 0.05, with the same data, batch size, number of epochs and seed. The baseline uses no warmup and no decay.

**Evaluation.** After training, test accuracy on the 10,000 test images is computed for both ClipSign-SGD and the baseline, and both numbers are printed and saved to a results file.

## 4. Results

| Optimizer | Learning rate | Test accuracy (%) |
| --- | --- | --- |
| SGD + momentum (baseline) | 0.05 | 97.6 |
| ClipSign-SGD | 0.004 | 97.9 |

ClipSign-SGD reaches slightly higher test accuracy than the baseline. In an ablation (not required for reproduction), removing the dead zone (τ = 0) lowers accuracy to 97.2%.

## 5. Conclusion

Ignoring small gradient components and smoothing the resulting sign vector gives a simple, scale-robust optimizer that is competitive with SGD with momentum on a small benchmark.
